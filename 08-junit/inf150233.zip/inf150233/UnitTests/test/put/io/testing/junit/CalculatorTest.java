package put.io.testing.junit;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

class CalculatorTest {
    Calculator calculator;

    @BeforeEach
    void setUp(){
        calculator = new Calculator();
    }

    @Test
    void testAddPositive(){
        int a = 10;
        int b = 10;
        int Result = calculator.add(a,b);
        int expected = a+b;
        assertEquals(expected, Result);
    }

    @Test
    void testAddNegative(){
        int a = -5;
        int b =  10;
        int Result = calculator.add(a,b);
        int expected = a+b;
        assertEquals(expected, Result);
    }


    @Test
    void testMultiplyPositive(){
        int a = 2;
        int b = 2;
        int Result = calculator.multiply(a,b);
        int expected = a*b;
        assertEquals(expected, Result);
    }

    @Test
    void testMultiplyNegative() {
        int a = -2;
        int b = 3;
        int Result = calculator.multiply(a, b);
        int expected = a * b;
        assertEquals(expected, Result);

    }

    @Test
    void testaddPositiveNumbers() {
        int a = -1;
        int b = 5;
        IllegalArgumentException thrown = assertThrows(IllegalArgumentException.class,()->{
            calculator.addPositiveNumbers(a,b);
        });
    }


}


