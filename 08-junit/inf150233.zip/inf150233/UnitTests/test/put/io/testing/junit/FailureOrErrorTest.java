package put.io.testing.junit;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;


public class FailureOrErrorTest {
    Calculator calculator;

    @BeforeEach
    void setUp(){
            calculator = new Calculator();
        }
    //failure
        @Test void test1(){
            int a = 10;
            int b = 10;
            int Result = calculator.add(a,b);
            int expected = a*b;
            assertEquals(expected, Result);
        }
    //error
    @Test
    void test2() {
        assertEquals(10/0,0);
    }

    @Test
    void test3(){
        try{
            assertEquals(1,0);
        }catch(Throwable throwable){
            throwable.printStackTrace();
        }

        //JUnit oczekuje na obiekt klasy org.opentest4j.AssertionFailedError

    }

}


