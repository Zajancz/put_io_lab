package put.io.testing.mocks;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;
import put.io.testing.mocks.ExpenseRepository;
import java.util.Collections;

import put.io.students.fancylibrary.database.IFancyDatabase;

import org.junit.jupiter.api.Test;

import org.mockito.InOrder;

public class ExpenseRepositoryTest {


    @Test
    void loadExpenses() {
        IFancyDatabase mockObject = mock(IFancyDatabase.class);
        when(mockObject.queryAll()).thenReturn(Collections.emptyList());

        //expenseRepository = new ExpenseRepository(mockObject);
        //expenseRepository.loadExpenses();


        ExpenseRepository repository = new ExpenseRepository(mockObject);
        //ExpenseRepository repository = new ExpenseRepository(new MyDatabase());
        repository.loadExpenses();
        //assertNotNull(repository.getExpenses());

        InOrder inOrder = inOrder(mockObject);
        inOrder.verify(mockObject).connect();
        inOrder.verify(mockObject).queryAll();
        inOrder.verify(mockObject).close();

        //assertTrue(repository.getExpenses().isEmpty());
        assertNotNull(repository.getExpenses());
    }


    @Test
    void saveExpensesTest() {
        IFancyDatabase mockObject = mock(IFancyDatabase.class);
        when(mockObject.queryAll()).thenReturn(Collections.emptyList());

        ExpenseRepository repository = new ExpenseRepository(mockObject);
        repository.addExpense(new Expense());
        repository.addExpense(new Expense());
        repository.addExpense(new Expense());
        repository.addExpense(new Expense());
        repository.addExpense(new Expense());
        repository.saveExpenses();


        verify(mockObject, times(5)).persist(any(Expense.class));

        assertFalse(repository.getExpenses().isEmpty());
    }


}
