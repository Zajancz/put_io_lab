package put.io.testing.audiobooks;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;


class AudiobookPriceCalculatorTest {

    AudiobookPriceCalculator audiobookPriceCalculator;
    Audiobook audiobook;

    @BeforeEach
    void setUp(){
        audiobookPriceCalculator = new AudiobookPriceCalculator();
        audiobook = new Audiobook("",1.0);
    }

    @Test
    void testSubscriberTrueStandart(){
        var customer = new Customer("", Customer.LoyaltyLevel.STANDARD,true);
        var expectedResult = 0.0;
        var actualResult = audiobookPriceCalculator.calculate(customer,audiobook);
        assertEquals(expectedResult,actualResult);
    }


    @Test
    void testSubscriberFalseStandart(){
        var customer = new Customer("", Customer.LoyaltyLevel.STANDARD,false);
        var expectedResult = audiobook.getStartingPrice();
        var actualResult = audiobookPriceCalculator.calculate(customer,audiobook);
        assertEquals(expectedResult,actualResult);
    }

    @Test
    void testSubscriberTrueSilver(){
        var customer = new Customer("", Customer.LoyaltyLevel.SILVER,true);
        var expectedResult = 0.0;
        var actualResult = audiobookPriceCalculator.calculate(customer,audiobook);
        assertEquals(expectedResult,actualResult);
    }

    @Test
    void testSubscriberFalseSilver(){
        var customer = new Customer("", Customer.LoyaltyLevel.SILVER,false);
        var expectedResult = 0.9 * audiobook.getStartingPrice();
        var actualResult = audiobookPriceCalculator.calculate(customer,audiobook);
        assertEquals(expectedResult,actualResult);
    }


    @Test
    void testSubscriberTrueGold(){
        var customer = new Customer("", Customer.LoyaltyLevel.GOLD,true);
        var expectedResult = 0.0;
        var actualResult = audiobookPriceCalculator.calculate(customer,audiobook);
        assertEquals(expectedResult,actualResult);
    }

    @Test
    void testSubscriberFalseGold(){
        var customer = new Customer("", Customer.LoyaltyLevel.GOLD,false);
        var expectedResult = 0.8 * audiobook.getStartingPrice();
        var actualResult = audiobookPriceCalculator.calculate(customer,audiobook);
        assertEquals(expectedResult,actualResult);
    }

}